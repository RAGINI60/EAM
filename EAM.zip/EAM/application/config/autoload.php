<?php
defined('BASEPATH') or exit('No direct script access allowed');


$autoload['packages'] = array();



$autoload['libraries'] = array('database', 'session');


$autoload['drivers'] = array();


$autoload['helper'] = array('url', 'file', 'sak_helper');


$autoload['config'] = array();


$autoload['language'] = array();


$autoload['model'] = array();
